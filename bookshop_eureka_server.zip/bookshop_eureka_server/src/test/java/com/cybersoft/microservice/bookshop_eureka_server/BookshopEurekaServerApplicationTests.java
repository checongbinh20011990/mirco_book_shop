package com.cybersoft.microservice.bookshop_eureka_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshopEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
