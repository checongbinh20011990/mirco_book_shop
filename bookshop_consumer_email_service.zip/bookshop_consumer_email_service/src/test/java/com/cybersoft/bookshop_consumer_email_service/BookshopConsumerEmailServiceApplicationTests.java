package com.cybersoft.bookshop_consumer_email_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshopConsumerEmailServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
