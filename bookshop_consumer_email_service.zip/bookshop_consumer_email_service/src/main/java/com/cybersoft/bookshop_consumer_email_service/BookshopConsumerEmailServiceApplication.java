package com.cybersoft.bookshop_consumer_email_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookshopConsumerEmailServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookshopConsumerEmailServiceApplication.class, args);
	}

}
