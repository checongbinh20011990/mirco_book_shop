package com.cybersoft.bookshop_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookshopGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookshopGatewayApplication.class, args);
	}

}
