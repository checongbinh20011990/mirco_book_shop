package com.cybersoft.bookshop_product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshopProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
